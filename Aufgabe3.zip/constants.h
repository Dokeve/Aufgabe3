#pragma once
constexpr int N =3;
constexpr int Nrow = 3;
constexpr int Ncol = 9;
 